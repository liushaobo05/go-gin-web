package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"os"
	"text/template"
)

var data = `
    name: sigin
    method: POST
    version: v1
    path: /signIn
    auth: false
    summary: "用户登陆"
    description: "用户登陆接口"
    params:
        body:
            type: object
            items:
                username:
                    type: string
                    required: true
                    desc: 用户名
                password:
                    type: string
                    required: true
                    desc: 密码
`

type API struct {
	Name        string `json:"name"`
	Method      string `json:"method"`
	Version     string `json:"version"`
	Path        string `json:"path"`
	Auth        bool   `json:"auth"`
	Summary     string `json:"summary,omitempty"`
	Description string `json:"description,omitempty"`
	Params      Parmas `json:"parmas,omitempty"`
}

// 请求参数
type Parmas struct {
	Query  Query  `json:"query,omitempty"`
	Header Header `json:"header,omitempty"`
	Body   Body   `json:"body,omitempty"`
}

type Header struct {
	Items []Items `json:"items,omitempty"`
}

type Query struct {
	Items []Items `json:"items,omitempty"`
}

type Items struct {
	Name     string `json:"name,omitempty"`
	Value    string `json:"value,omitempty"`
	Desc     string `json:"desc,omitempty"`
	Default  string `json:"default,omitempty"`
	Required bool   `json:"required,omitempty"`
}

type Body struct {
	Param
}

// Param 表示参数类型
type Param struct {
	Type     string            `json:"type,omitempty"`
	Example  string            `json:"example,omitempty"`
	Required bool              `json:"required,omitempty"`
	Items    map[string]*Param `json:"items,omitempty"`
	Desc     string            `json:"desc,omitempty"`
}

func NewApi(path string) (API, error) {
	var api API

	byteStr, err := ioutil.ReadFile(path)
	if err != nil {
		return api, err
	}

	if err := json.Unmarshal(byteStr, &api); err != nil {
		return api, err
	}

	return api, nil
}

func main() {
	t, err := template.ParseFiles("./swagger.tpl", "./meta.tpl")
	if err != nil {
		fmt.Println("模版加载失败", err)
		panic(err)
	}

	data, _ := NewApi("./data.json")

	fmt.Printf("ddddd========%+v", data)

	if err = t.ExecuteTemplate(os.Stdout, "index", data); err != nil {
		panic(err)
	}
}
